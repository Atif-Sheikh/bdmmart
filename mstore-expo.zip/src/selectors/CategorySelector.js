/** @format */

// import { createSelector } from 'reselect'

const categories = (state) => state.categories.list;

export { categories };
