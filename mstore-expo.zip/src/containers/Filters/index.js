
import React from "react";
import { View, Text, TouchableOpacity, ScrollView, Animated, Image, Platform } from "react-native";
import { connect } from "react-redux";
import { Styles, Images, Config, Languages, Constants, withTheme } from "@common";
import { Timer, toast, BlockTimer, currencyFormatter } from "@app/Omni";
import {
  AnimatedHeader,
  ProductCatalog,
  ProductTags
} from "@components";
import styles from "./styles";
import Icon from "@expo/vector-icons/FontAwesome";
import Slider from 'react-native-fluid-slider';
import Color from "../../common/Color";

class Filters extends React.PureComponent {
  constructor(props){
    super(props)
    this.filter = {}
    this.state = {
      scrollY: new Animated.Value(0),
      expanded: true,
      value: 2000
    }
  }


  render() {
    const { categories, onBack, tags, navigation } = this.props;
    const {scrollY} = this.state
    const {
      theme:{
        colors:{
          background, text
        }
      }
    } = this.props

    return (
      <ScrollView style={[styles.container, {backgroundColor: background}]}>

        <View style={styles.content}>
          <Text
            style={[
              styles.headerLabel,
              {color: text}
            ]}>
            {Languages.Filters}
          </Text>
           
          
          <ProductCatalog categories={categories} onSelectCategory={this.onSelectCategory}/>
          <ProductTags tags={tags} onSelectTag={this.onSelectTag}/>

          <Text style={[styles.pricing, {color: text}]}>{Languages.Pricing}</Text>
          <View style={styles.row}>
            <Text style={styles.label}>{currencyFormatter(0)}</Text>
            <Text style={styles.value}>{currencyFormatter(this.state.value)}</Text>
            <Text style={styles.label}>{currencyFormatter(4000)}</Text>
          </View>
          <View style={styles.slideWrap}>
            <Slider
              value={this.state.value}
              onValueChange={this.onValueChange}
              onSlidingComplete={(value) => { console.warn('Sliding Complete with value: ', value) }}
              minimumTrackTintColor={Color.primary}
              maximumTrackTintColor='#bdc2cc'
              thumbTintColor={Color.primary}
              minimumValue={0}
              maximumValue={4000}/>
          </View>

          <TouchableOpacity style={styles.btnFilter} onPress={this.onFilter}>
            <Text style={styles.filterText}>{Languages.Filter}</Text>
          </TouchableOpacity>

          <TouchableOpacity style={styles.btnClear} onPress={this.clearFilter}>
            <Text style={styles.clearFilter}>{Languages.ClearFilter}</Text>
          </TouchableOpacity>
        </View>
      </ScrollView>
    );
  }

  onSelectCategory = (item)=>{
    this.filter = {...this.filter, category: item.id}
  }

  onSelectTag = (item)=>{
    this.filter = {...this.filter, tag: item.id}
  }

  onValueChange = (value)=>{
    this.setState({ value })
    this.filter = {...this.filter, max_price: value}
  }

  onFilter = ()=>{
    this.props.navigation.state.params.onSearch(this.filter)
    this.props.onBack()
  }

  clearFilter = ()=>{
    this.props.navigation.state.params.onSearch({})
    this.props.onBack()
  }

  componentDidMount(){
    this.props.fetchTags()
  }
}

Filters.defaultProps = {
  tags: []
}

const mapStateToProps = (state) => {
  return {
    categories: state.categories.list,
    tags: state.tags.list,
  };
};

function mergeProps(stateProps, dispatchProps, ownProps) {
  const { netInfo } = stateProps;
  const { dispatch } = dispatchProps;
  const { actions } = require("@redux/TagRedux");

  return {
    ...ownProps,
    ...stateProps,
    fetchTags: () => {
      actions.fetchTags(dispatch);
    },
  };
}

export default connect(
  mapStateToProps,
  undefined,
  mergeProps
)(withTheme(Filters));
